import React, { useState } from 'react';
import { PlusCircle, Edit2, Trash2 } from 'lucide-react';
import { Notice } from '../types';
import { getNotices, addNotice, deleteNotice, updateNotice } from '../utils/storage';
import { useTheme } from '../context/ThemeContext';

export default function AdminPanel() {
  const [isEditing, setIsEditing] = useState(false);
  const [editingNotice, setEditingNotice] = useState<Notice | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    category: '',
    expiryDate: '',
    important: false,
  });
  const { isDarkMode } = useTheme();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isEditing && editingNotice) {
      updateNotice({
        ...editingNotice,
        ...formData,
      });
    } else {
      const newNotice: Notice = {
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
        ...formData,
      };
      addNotice(newNotice);
    }
    resetForm();
  };

  const resetForm = () => {
    setFormData({
      title: '',
      content: '',
      category: '',
      expiryDate: '',
      important: false,
    });
    setIsEditing(false);
    setEditingNotice(null);
  };

  const handleEdit = (notice: Notice) => {
    setIsEditing(true);
    setEditingNotice(notice);
    setFormData({
      title: notice.title,
      content: notice.content,
      category: notice.category,
      expiryDate: notice.expiryDate,
      important: notice.important,
    });
  };

  const inputClasses = `mt-1 block w-full rounded-md shadow-sm transition-colors duration-200
    ${isDarkMode 
      ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-400' 
      : 'bg-white border-gray-300 text-gray-900 placeholder-gray-500'}
    focus:border-blue-500 focus:ring-blue-500`;

  return (
    <div className="max-w-4xl mx-auto p-4">
      <form onSubmit={handleSubmit} className={`rounded-lg shadow-md p-6 mb-8 transition-colors duration-200
        ${isDarkMode ? 'bg-gray-800' : 'bg-white'}`}>
        <h2 className={`text-xl font-semibold mb-4 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
          {isEditing ? 'Edit Notice' : 'Add New Notice'}
        </h2>
        <div className="space-y-4">
          <div>
            <label className={`block text-sm font-medium ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
              Title
            </label>
            <input
              type="text"
              required
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className={inputClasses}
            />
          </div>
          <div>
            <label className={`block text-sm font-medium ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
              Content
            </label>
            <textarea
              required
              value={formData.content}
              onChange={(e) => setFormData({ ...formData, content: e.target.value })}
              className={inputClasses}
              rows={4}
            />
          </div>
          <div>
            <label className={`block text-sm font-medium ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
              Category
            </label>
            <input
              type="text"
              required
              value={formData.category}
              onChange={(e) => setFormData({ ...formData, category: e.target.value })}
              className={inputClasses}
            />
          </div>
          <div>
            <label className={`block text-sm font-medium ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
              Expiry Date
            </label>
            <input
              type="date"
              required
              value={formData.expiryDate}
              onChange={(e) => setFormData({ ...formData, expiryDate: e.target.value })}
              className={inputClasses}
            />
          </div>
          <div className="flex items-center">
            <input
              type="checkbox"
              id="important"
              checked={formData.important}
              onChange={(e) => setFormData({ ...formData, important: e.target.checked })}
              className="h-4 w-4 text-blue-600 focus:ring-blue-500 rounded"
            />
            <label htmlFor="important" className={`ml-2 block text-sm ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
              Mark as Important
            </label>
          </div>
          <div className="flex gap-2">
            <button
              type="submit"
              className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <PlusCircle className="mr-2" size={16} />
              {isEditing ? 'Update Notice' : 'Add Notice'}
            </button>
            {isEditing && (
              <button
                type="button"
                onClick={resetForm}
                className={`inline-flex items-center px-4 py-2 border rounded-md shadow-sm text-sm font-medium
                  ${isDarkMode 
                    ? 'border-gray-600 text-gray-300 bg-gray-700 hover:bg-gray-600' 
                    : 'border-gray-300 text-gray-700 bg-white hover:bg-gray-50'}
                  focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500`}
              >
                Cancel
              </button>
            )}
          </div>
        </div>
      </form>

      <div className="space-y-4">
        <h2 className={`text-xl font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
          Manage Notices
        </h2>
        {getNotices().map(notice => (
          <div key={notice.id} className={`rounded-lg shadow-md p-6 transition-colors duration-200
            ${isDarkMode ? 'bg-gray-800' : 'bg-white'}`}>
            <div className="flex justify-between items-start">
              <div>
                <h3 className={`text-lg font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                  {notice.title}
                </h3>
                <p className={`mt-1 ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                  {notice.content}
                </p>
                <div className={`mt-2 text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                  Category: {notice.category} | Expires: {new Date(notice.expiryDate).toLocaleDateString()}
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => handleEdit(notice)}
                  className={`p-2 rounded-full transition-colors duration-200
                    ${isDarkMode 
                      ? 'text-blue-400 hover:bg-gray-700' 
                      : 'text-blue-600 hover:bg-blue-50'}`}
                >
                  <Edit2 size={16} />
                </button>
                <button
                  onClick={() => deleteNotice(notice.id)}
                  className={`p-2 rounded-full transition-colors duration-200
                    ${isDarkMode 
                      ? 'text-red-400 hover:bg-gray-700' 
                      : 'text-red-600 hover:bg-red-50'}`}
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}