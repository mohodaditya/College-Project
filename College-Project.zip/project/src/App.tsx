import React, { useState } from 'react';
import { BellRing, Sun, Moon } from 'lucide-react';
import NoticeBoard from './components/NoticeBoard';
import AdminPanel from './components/AdminPanel';
import Login from './components/Login';
import { useTheme } from './context/ThemeContext';

export default function App() {
  const [isAdminView, setIsAdminView] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const { isDarkMode, toggleDarkMode } = useTheme();

  const handleLogin = (success: boolean) => {
    setIsAuthenticated(success);
  };

  return (
    <div className={`min-h-screen ${isDarkMode ? 'dark bg-gray-900' : 'bg-gray-50'} transition-colors duration-200`}>
      <header className={`${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white'} shadow-lg border-b transition-colors duration-200`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <div className={`p-2 rounded-full ${isDarkMode ? 'bg-gray-700' : 'bg-blue-100'}`}>
                <BellRing className={`h-6 w-6 ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`} />
              </div>
              <h1 className={`text-2xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                College Notice Board
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={toggleDarkMode}
                className={`p-2 rounded-full hover:bg-opacity-80 transition-colors
                  ${isDarkMode ? 'bg-gray-700 text-gray-200' : 'bg-gray-200 text-gray-600'}`}
                aria-label="Toggle dark mode"
              >
                {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
              </button>
              <button
                onClick={() => {
                  if (isAdminView && !isAuthenticated) {
                    setIsAdminView(true);
                  } else {
                    setIsAdminView(!isAdminView);
                    if (!isAdminView) {
                      setIsAuthenticated(false);
                    }
                  }
                }}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200
                  ${isDarkMode 
                    ? 'text-white bg-blue-600 hover:bg-blue-700' 
                    : 'text-white bg-blue-600 hover:bg-blue-700'} 
                  focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500`}
              >
                {isAdminView ? 'View Notices' : 'Admin Panel'}
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className={`max-w-7xl mx-auto py-6 sm:px-6 lg:px-8 ${isDarkMode ? 'text-gray-200' : 'text-gray-900'}`}>
        {isAdminView ? (
          isAuthenticated ? (
            <AdminPanel />
          ) : (
            <Login onLogin={handleLogin} />
          )
        ) : (
          <NoticeBoard />
        )}
      </main>
    </div>
  );
}