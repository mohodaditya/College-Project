export interface Notice {
  id: string;
  title: string;
  content: string;
  category: string;
  expiryDate: string;
  createdAt: string;
  important: boolean;
}

export interface AdminCredentials {
  username: string;
  password: string;
}