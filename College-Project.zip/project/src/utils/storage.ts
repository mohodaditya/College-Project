import { Notice } from '../types';

// Initial demo notices
const initialNotices: Notice[] = [
  {
    id: '1',
    title: 'Summer Semester Registration',
    content: 'Registration for summer semester courses begins next week. Please check your academic portal for eligibility.',
    category: 'Academic',
    expiryDate: '2024-06-01',
    createdAt: '2024-03-15',
    important: true,
  },
  {
    id: '2',
    title: 'Campus Career Fair',
    content: 'Annual career fair will be held in the main auditorium. Over 50 companies will be present.',
    category: 'Events',
    expiryDate: '2024-05-15',
    createdAt: '2024-03-10',
    important: false,
  },
];

// Initialize notices in localStorage if not present
if (!localStorage.getItem('notices')) {
  localStorage.setItem('notices', JSON.stringify(initialNotices));
}

export const getNotices = (): Notice[] => {
  return JSON.parse(localStorage.getItem('notices') || '[]');
};

export const addNotice = (notice: Notice): void => {
  const notices = getNotices();
  notices.unshift(notice);
  localStorage.setItem('notices', JSON.stringify(notices));
};

export const deleteNotice = (id: string): void => {
  const notices = getNotices().filter(notice => notice.id !== id);
  localStorage.setItem('notices', JSON.stringify(notices));
};

export const updateNotice = (updatedNotice: Notice): void => {
  const notices = getNotices().map(notice => 
    notice.id === updatedNotice.id ? updatedNotice : notice
  );
  localStorage.setItem('notices', JSON.stringify(notices));
};